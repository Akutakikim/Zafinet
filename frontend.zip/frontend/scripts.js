// Smooth Scroll Navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Background Animation (change colors over time)
function changeBackground() {
    const colors = ['#1e2a47', '#2c3e50', '#34495e', '#5f6a77', '#4e5d6c'];
    let index = 0;
    setInterval(() => {
        document.body.style.backgroundColor = colors[index];
        index = (index + 1) % colors.length;
    }, 3000); // Change every 3 seconds
}

// Start background animation on page load
window.onload = changeBackground;

// Form Validation for Contact Page
document.querySelector("form").addEventListener("submit", function(e) {
    let name = document.querySelector("#name").value;
    let email = document.querySelector("#email").value;
    let message = document.querySelector("#message").value;

    if (!name || !email || !message) {
        e.preventDefault();
        alert("All fields must be filled out.");
    } else {
        alert("Your message has been sent!");
    }
});

// Show the modal when the page loads
window.onload = () => {
    document.getElementById('specialModal').style.display = 'flex';
};

// Close the modal when the user clicks the "Close" button
document.getElementById('closeModal').addEventListener('click', () => {
    document.getElementById('specialModal').style.display = 'none';
});